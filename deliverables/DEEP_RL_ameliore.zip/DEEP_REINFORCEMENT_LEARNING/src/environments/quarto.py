import numpy as np
from typing import Tuple, Dict, Any, Optional, List
from .base_env import BaseEnvironment

PIECE_SYMBOLS = {
    0: "b\u25a0",  # Petite Claire Carree Pleine
    1: "B\u25a0",  # Grande Claire Carree Pleine
    2: "r\u25a0",  # Petite Foncee Carree Pleine
    3: "R\u25a0",  # Grande Foncee Carree Pleine
    4: "b\u25cf",  # Petite Claire Ronde  Pleine
    5: "B\u25cf",  # Grande Claire Ronde  Pleine
    6: "r\u25cf",  # Petite Foncee Ronde  Pleine
    7: "R\u25cf",  # Grande Foncee Ronde  Pleine
    8: "b\u25a1",  # Petite Claire Carree Creuse
    9: "B\u25a1",  # Grande Claire Carree Creuse
    10: "r\u25a1",  # Petite Foncee Carree Creuse
    11: "R\u25a1",  # Grande Foncee Carree Creuse
    12: "b\u25cb",  # Petite Claire Ronde  Creuse
    13: "B\u25cb",  # Grande Claire Ronde  Creuse
    14: "r\u25cb",  # Petite Foncee Ronde  Creuse
    15: "R\u25cb",  # Grande Foncee Ronde  Creuse
}

PIECE_ATTRS_NAMES = [
    ("Petite", "Grande"),
    ("Claire", "Foncee"),
    ("Carree", "Ronde"),
    ("Pleine", "Creuse"),
]


class Quarto(BaseEnvironment):
    is_two_player = True
    ATTRS = np.array([[(p >> b) & 1 for b in range(4)] for p in range(16)], dtype=np.int32)
    LINE_INDICES = np.array(
        [[4 * r + c for c in range(4)] for r in range(4)]
        + [[4 * r + c for r in range(4)] for c in range(4)]
        + [[0, 5, 10, 15], [3, 6, 9, 12]],
        dtype=np.int32,
    )

    def __init__(self, opponent_type: str = "random", seed: Optional[int] = None):
        self.opponent_type = opponent_type
        if opponent_type not in {"random", "heuristic"}:
            raise ValueError("Unknown opponent type")
        self.board = np.full(16, -1, dtype=np.int32)
        self.available = np.ones(16, dtype=bool)
        self.current_piece = -1
        self._action_space_size = 16
        self._done = False
        super().__init__(seed)

    # Utilitaires pieces

    @staticmethod
    def piece_symbol(piece_id: int) -> str:
        if piece_id < 0 or piece_id > 15:
            return "?"
        return PIECE_SYMBOLS[piece_id]

    @staticmethod
    def piece_description(piece_id: int) -> str:
        if piece_id < 0:
            return "aucune"
        attrs = [(piece_id >> b) & 1 for b in range(4)]
        return ", ".join(PIECE_ATTRS_NAMES[i][attrs[i]] for i in range(4))

    # Encodage de l'etat (101 dimensions)

    def _encode_piece_attrs(self, piece_id: int) -> np.ndarray:
        """Encode une piece en 5 valeurs : [occupee, taille, couleur, forme, remplissage]."""
        if piece_id < 0:
            return np.zeros(5, dtype=np.float32)
        enc = np.zeros(5, dtype=np.float32)
        enc[0] = 1.0  # case occupee / piece presente
        enc[1] = float((piece_id >> 0) & 1)  # taille
        enc[2] = float((piece_id >> 1) & 1)  # couleur
        enc[3] = float((piece_id >> 2) & 1)  # forme
        enc[4] = float((piece_id >> 3) & 1)  # remplissage
        return enc

    def _get_state(self) -> np.ndarray:
        # Plateau : 16 cases x 5 valeurs = 80 dimensions
        board_enc = np.zeros(80, dtype=np.float32)
        for i in range(16):
            board_enc[i * 5 : (i + 1) * 5] = self._encode_piece_attrs(self.board[i])

        # Piece courante : 5 dimensions
        piece_enc = self._encode_piece_attrs(self.current_piece)

        # Disponibilite : 16 dimensions
        avail_enc = self.available.astype(np.float32)

        return np.concatenate([board_enc, piece_enc, avail_enc])
        # Total : 80 + 5 + 16 = 101

    def reset(self, seed=None) -> np.ndarray:
        self.reseed(seed)
        self.board = np.full(16, -1, dtype=np.int32)
        self.available = np.ones(16, dtype=bool)
        self._done = False
        # L'adversaire choisit une premiere piece pour l'agent
        piece = self._opponent_pick_piece_for_agent()
        self.current_piece = piece
        self.available[piece] = False
        return self._get_state()

    def step(self, action: int) -> Tuple[np.ndarray, float, bool, Dict]:
        self._validate_action(action)
        if self._done:
            return self._get_state(), 0.0, True, {}

        pos = action
        if pos < 0 or pos >= 16 or self.board[pos] != -1:
            return self._get_state(), -1.0, True, {"error": "placement invalide"}
        if self.current_piece < 0:
            return self._get_state(), -1.0, True, {"error": "aucune piece"}

        # L'agent place sa piece
        self.board[pos] = self.current_piece
        if self._check_win():
            self._done = True
            return self._get_state(), 1.0, True, {"winner": "agent", "outcome": "win"}

        if not np.any(self.board == -1) or not np.any(self.available):
            self._done = True
            return self._get_state(), 0.0, True, {"result": "draw", "outcome": "draw"}

        # L'agent choisit une piece pour l'adversaire
        opp_piece = self._agent_pick_piece_for_opponent()
        if opp_piece < 0:
            self._done = True
            return self._get_state(), 0.0, True, {"result": "draw", "outcome": "draw"}
        self.available[opp_piece] = False

        # L'adversaire place sa piece
        opp_pos = self._opponent_place(opp_piece)
        if opp_pos is not None:
            self.board[opp_pos] = opp_piece
            if self._check_win():
                self._done = True
                return self._get_state(), -1.0, True, {"winner": "opponent", "outcome": "loss"}

        if not np.any(self.board == -1) or not np.any(self.available):
            self._done = True
            return self._get_state(), 0.0, True, {"result": "draw", "outcome": "draw"}

        # L'adversaire choisit une piece pour l'agent
        agent_piece = self._opponent_pick_piece_for_agent()
        if agent_piece < 0:
            self._done = True
            return self._get_state(), 0.0, True, {"result": "draw", "outcome": "draw"}
        self.current_piece = agent_piece
        self.available[agent_piece] = False

        return self._get_state(), 0.0, False, {}

    # Verification de victoire

    def _get_lines(self) -> List[np.ndarray]:
        return self.board[self.LINE_INDICES]

    def _check_win(self) -> bool:
        lines = self._get_lines()
        full = np.all(lines >= 0, axis=1)
        common_one = np.bitwise_and.reduce(lines, axis=1) != 0
        common_zero = np.bitwise_or.reduce(lines, axis=1) != 15
        return bool(np.any(full & (common_one | common_zero)))

    def _would_piece_win_somewhere(self, piece: int) -> bool:
        """Verifie si cette piece peut gagner en etant placee quelque part."""
        empty = np.where(self.board == -1)[0]
        if len(empty) == 0:
            return False
        boards = np.tile(self.board, (len(empty), 1))
        boards[np.arange(len(empty)), empty] = piece
        lines = boards[:, self.LINE_INDICES]
        full = np.all(lines >= 0, axis=2)
        common = (np.bitwise_and.reduce(lines, axis=2) != 0) | (np.bitwise_or.reduce(lines, axis=2) != 15)
        return bool(np.any(full & common))

    def _count_dangerous_lines(self, piece: int) -> int:
        danger = 0
        piece_attrs = self.ATTRS[piece]
        for line in self._get_lines():
            filled = line[line != -1]
            empty_count = np.sum(line == -1)
            if len(filled) < 2 or empty_count == 0:
                continue
            filled_attrs = self.ATTRS[filled]
            for attr in range(4):
                vals = set(filled_attrs[:, attr])
                if len(vals) == 1 and piece_attrs[attr] == list(vals)[0]:
                    danger += len(filled) ** 2
        return danger

    # Choix de piece : AGENT pour l'adversaire
    def _agent_pick_piece_for_opponent(self) -> int:
        avail = np.where(self.available)[0]
        if len(avail) == 0:
            return -1

        # eliminer les pieces qui donnent la victoire
        safe = [int(p) for p in avail if not self._would_piece_win_somewhere(int(p))]
        candidates = safe if safe else [int(p) for p in avail]

        if len(candidates) == 1:
            return candidates[0]

        # choisir la moins dangereuse
        scored = [(p, self._count_dangerous_lines(p)) for p in candidates]
        scored.sort(key=lambda x: x[1])
        best_score = scored[0][1]
        best = [p for p, s in scored if s == best_score]
        return int(self.rng.choice(best))

    # Choix de piece : ADVERSAIRE pour l'agent
    def _opponent_pick_piece_for_agent(self) -> int:
        avail = np.where(self.available)[0]
        if len(avail) == 0:
            return -1

        if self.opponent_type == "random":
            return int(self.rng.choice(avail))

        # Mode heuristic avec la meme logique que l'agent
        safe = [int(p) for p in avail if not self._would_piece_win_somewhere(int(p))]
        candidates = safe if safe else [int(p) for p in avail]

        if len(candidates) == 1:
            return candidates[0]

        scored = [(p, self._count_dangerous_lines(p)) for p in candidates]
        scored.sort(key=lambda x: x[1])
        best_score = scored[0][1]
        best = [p for p, s in scored if s == best_score]
        return int(self.rng.choice(best))

    # Placement de l'adversaire

    def _opponent_place(self, piece: int) -> Optional[int]:
        empty = np.where(self.board == -1)[0]
        if len(empty) == 0:
            return None
        if self.opponent_type == "heuristic":
            return self._heuristic_place(piece, empty)
        return int(self.rng.choice(empty))

    def _heuristic_place(self, piece: int, empty: np.ndarray) -> int:
        # Gagner si possible
        for pos in empty:
            self.board[pos] = piece
            if self._check_win():
                self.board[pos] = -1
                return int(pos)
            self.board[pos] = -1
        return int(self.rng.choice(empty))

    # Affichage

    def render(self) -> None:
        b = self.board.reshape(4, 4)
        print("  Quarto Board:")
        print("       0     1     2     3")
        print("    +-----+-----+-----+-----+")
        for i, row in enumerate(b):
            cells = []
            for p in row:
                if p == -1:
                    cells.append("  .  ")
                else:
                    sym = PIECE_SYMBOLS[p]
                    cells.append(f"{p:2d} {sym}")
            print(f"  {i} |{'|'.join(cells)}|")
            print("    +-----+-----+-----+-----+")
        if self.current_piece >= 0:
            sym = PIECE_SYMBOLS[self.current_piece]
            desc = self.piece_description(self.current_piece)
            print(f"  Piece a placer: {self.current_piece} ({sym}) - {desc}")
        avail = np.where(self.available)[0]
        if len(avail) > 0:
            print(f"  Disponibles: {', '.join(f'{p}({PIECE_SYMBOLS[p]})' for p in avail)}")

    @property
    def observation_space(self) -> int:
        return 101  # 16*5 + 5 + 16

    @property
    def action_space(self) -> int:
        return self._action_space_size

    def get_valid_actions(self, state: Any = None) -> np.ndarray:
        if self._done:
            return np.array([], dtype=np.int32)
        if state is not None:
            encoded = np.asarray(state)
            if encoded.shape == (101,):
                return np.where(encoded[:80:5] == 0)[0].astype(np.int32)
        return np.where(self.board == -1)[0].astype(np.int32)
