"""NumPy reinforcement learning laboratory."""
